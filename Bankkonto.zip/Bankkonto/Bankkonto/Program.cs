﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

public class Konto
{
    private List<string> transaktionen;// speichert die Liste aller Transaktionen
    public decimal Kontostand { get; private set; } // speichert Kontostand
            public string Kontonummer { get; private set; }// Speichert 3-stellige Kontonummer.



    // konstruktor konto -ohne startguthaben
    public Konto(string kontonummer)
    {
        Kontostand = 0;
        Kontonummer = kontonummer;
        transaktionen = new List<string>();
    }

   //mit startguthabn


    public void Einzahlen(decimal betrag)
    {
        if (betrag > 0)
        {
            Kontostand += betrag;
            transaktionen.Add($"Einzahlung: {betrag:C} am {DateTime.Now}");
          }   
             }

    public virtual bool Abheben(decimal betrag)
    {
              if (betrag > 0 && Kontostand >= betrag)
        {
            Kontostand -= betrag;
            transaktionen.Add($"Abhebung: {betrag:C} am {DateTime.Now}");
            return true;
        }
        transaktionen.Add($"Abhebungsversuch fehlgeschlagen: {betrag:C} am {DateTime.Now}");
        return false;
    }

    public void TransaktionshistorieAnzeigen()
    {
        Console.WriteLine("Transaktionshistorie:");
        foreach (var transaktion in transaktionen)
          {
            Console.WriteLine(transaktion);
        }
    }

    public int AnzahlTransaktionen()
    {
        return transaktionen.Count;
    }
}
// Konstruktor für ein Jugendkonto ohne Startguthaben
public class Jugendkonto : Konto
{
    public decimal Limit { get; private set; } // Speichert Limit für Abhebungen (Jugendkonto) 

    public Jugendkonto(decimal limit, string kontonummer) : base(kontonummer)
    {   
        Limit = limit;  //   Abhebungslimit.
    }
    // mit Startguthaben
    

    public override bool Abheben(decimal betrag)
    {
        if (betrag > 0 && betrag <= Limit && Kontostand >= betrag)
        {
            return base.Abheben(betrag);
           }
            return false;
     }       

    
}

    public class Program
{
    private static List<Konto> kontenListe = new List<Konto>(); //neue leere Liste

    public static void Main()
    {
        Hauptmenü();
    }

    private static void Hauptmenü()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("1. Neues Konto anlegen");
            Console.WriteLine("2. Auf Konto einzahlen");
            Console.WriteLine("3. Vom Konto abheben");
            Console.WriteLine("4. Alle Konten anzeigen");
              Console.WriteLine("5. Transaktionshistorie anzeigen");
          Console.WriteLine("6. Alles in Datei speichern");
            Console.WriteLine("7. Alles aus Datei laden");
            Console.WriteLine("8. Konto löschen");
            Console.WriteLine("9. Monatlichen Bericht anzeigen");
            Console.WriteLine("0. Beenden");

            var auswahl = Console.ReadKey();
            
            Console.Clear();

            switch (auswahl.KeyChar)
            {
                case '1':
                    NeuesKontoAnlegen();
                    break;
                case '2':
                    AufKontoEinzahlen();
                    break;
                case '3':
                    VomKontoAbheben();
                    break;
                case '4':
                    AlleKontenAnzeigen();
                    break;
                case '5':
                    TransaktionshistorieAnzeigen();
                    break;
                case '6':
                    AllesInDateiSpeichern();
                    break;
                case '7':
                    AllesAusDateiLaden();
                    break;
                case '8':
                    KontoLöschen();
                    break;
                case '9':
                    MonatlichenBerichtAnzeigen();
                    break;
                case '0':
                    return;
                default:
                    Console.WriteLine("Ungültige Auswahl Bitte erneut versuchen.");
                    break;
            }

            Console.WriteLine("drücken Sie eine beliebige Taste, um fortzufahren..");
            Console.ReadKey();
        }
    }
    // fehlermeldung wenn eingabe falsch 
    private static string EingabeMitPrüfung(Func<string, bool> prüfung, string fehlermeldung)
    {
        string eingabe;

        do
        {
            eingabe = Console.ReadLine();
            if (eingabe != null && prüfung(eingabe))
            {
                return eingabe;
            }
            Console.WriteLine(fehlermeldung);
        } while (true);
    }

    //konto anlegen
    private static void NeuesKontoAnlegen()
    {
        Console.Clear();
        Console.WriteLine("Welches Konto möchten Sie anlegen? (1 - Normales Konto, 2 - Jugendkonto)");

        string typ = EingabeMitPrüfung(
            e => e == "1" || e == "2",
            "Ungültige Eingabe. Bitte geben Sie '1' oder '2' ein."
        );

        Console.Write("Bitte geben Sie eine 3-stellige Kontonummer ein: ");
        string kontonummer = EingabeMitPrüfung(
            e => e.Length == 3 && int.TryParse(e, out _) && !kontenListe.Exists(k => k.Kontonummer == e),
            "Ungültige oder bereits verwendete Kontonummer. Bitte erneut versuchen."
        );

        if (typ == "1")
        {
            kontenListe.Add(new Konto(kontonummer));
            Console.WriteLine("Normales Konto angelegt.");
        }
        else if (typ == "2")
        {
            Console.Write("Limit für Jugendkonto: ");
            decimal limit = decimal.Parse(EingabeMitPrüfung(
                e => decimal.TryParse(e, out var val) && val > 0,
                "Bitte geben Sie ein gültiges Limit ein."
            ));

            kontenListe.Add(new Jugendkonto(limit, kontonummer));
            Console.WriteLine("Jugendkonto angelegt.");
        }
    }

    private static void AufKontoEinzahlen()
    {
        Console.Clear();
        Console.Write("Bitte geben Sie die 3-stellige Kontonummer ein: ");
        string kontonummer = EingabeMitPrüfung(
            e => kontenListe.Exists(k => k.Kontonummer == e),
            "Ungültige Kontonummer. Bitte erneut versuchen."
        );

        var konto = kontenListe.Find(k => k.Kontonummer == kontonummer);

        Console.Write("Einzahlungsbetrag: ");
        decimal betrag = decimal.Parse(EingabeMitPrüfung(
            e => decimal.TryParse(e, out var val) && val > 0,
            "Bitte geben Sie einen gültigen Betrag ein."
        ));

        konto.Einzahlen(betrag);
        Console.WriteLine("Betrag eingezahlt.");
    }
    //konto abheben
    private static void VomKontoAbheben()
    {
        Console.Clear();
        Console.Write("Bitte geben Sie die 3-stellige Kontonummer ein: ");
        string kontonummer = EingabeMitPrüfung(
            e => kontenListe.Exists(k => k.Kontonummer == e),
            "Ungültige Kontonummer. Bitte erneut versuchen."
        );

        var konto = kontenListe.Find(k => k.Kontonummer == kontonummer);

        Console.Write("Abhebungsbetrag: ");
        decimal betrag = decimal.Parse(EingabeMitPrüfung(
            e => decimal.TryParse(e, out var val) && val > 0,
            "Bitte geben Sie einen gültigen Betrag ein."
        ));

        if (konto.Abheben(betrag))
        {
            Console.WriteLine("Betrag abgehoben.");
        }
        else
        {
            Console.WriteLine("Abhebung fehlgeschlagen. Nicht genügend Guthaben oder Limit überschritten.");
        }
    }

    //konten abzeigen
    private static void AlleKontenAnzeigen()
    {
        Console.Clear();
        Console.WriteLine("Alle Konten:");
        foreach (var konto in kontenListe)
        {
            Console.WriteLine($"Kontonummer: {konto.Kontonummer}, Kontostand: {konto.Kontostand:C}");
        }
    }

    //Transaktionen
    private static void TransaktionshistorieAnzeigen()
    {
        Console.Clear();
        Console.Write("Bitte geben Sie die 3-stellige Kontonummer ein: ");
        string kontonummer = EingabeMitPrüfung(
            e => kontenListe.Exists(k => k.Kontonummer == e),
            "Ungültige Kontonummer. Bitte erneut versuchen."
        );

        var konto = kontenListe.Find(k => k.Kontonummer == kontonummer);
        konto.TransaktionshistorieAnzeigen();
    }

    //in datei speichern
    private static void AllesInDateiSpeichern()
    {
        Console.Clear();
        Console.Write("Bitte Dateiname eingeben: ");
        string dateiname = Console.ReadLine();

        using (var writer = new StreamWriter(dateiname))
        {
            foreach (var konto in kontenListe)
            {
                writer.WriteLine($"{konto.Kontonummer};{konto.Kontostand}");
            }
        }

        Console.WriteLine("Daten gespeichert.");
    }
    //laden
    private static void AllesAusDateiLaden()
    {
        Console.Clear();
        Console.Write("Bitte Dateiname eingeben: ");
        string dateiname = Console.ReadLine();

        if (!File.Exists(dateiname))
        {
            Console.WriteLine("Datei nicht gefunden.");
            return;
        }
        Console.WriteLine("Daten geladen.");
    }
    //löschen
    private static void KontoLöschen()
    {
        Console.Clear();
        Console.Write("Bitte geben Sie die 3-stellige Kontonummer ein: ");
        string kontonummer = EingabeMitPrüfung(
            e => kontenListe.Exists(k => k.Kontonummer == e),
            "Ungültige Kontonummer. Bitte erneut versuchen."
        );

        var konto = kontenListe.Find(k => k.Kontonummer == kontonummer);
        kontenListe.Remove(konto);
        Console.WriteLine("Konto gelöscht.");
    }
    //bericht
    private static void MonatlichenBerichtAnzeigen()
    {
        Console.Clear();
        Console.WriteLine("Monatlicher Bericht:");

        foreach (var konto in kontenListe)
        {
            Console.WriteLine($"Kontonummer: {konto.Kontonummer}, Transaktionen: {konto.AnzahlTransaktionen()}, Kontostand: {konto.Kontostand:C}");
        }
    }
}